# Discrete_Functions_Action_Integration_Hub
HUB that adds higher-level functionalities to discrete functions created from scratch.

## To download:

```
pip install git+https://github.com/IanAguiar-ai/Discrete_Functions_Action_Integration_Hub
```