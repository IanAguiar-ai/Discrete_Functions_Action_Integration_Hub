from .discrete_function import discrete_function, adjust_sample_on
