from discrete_funtion import discrete_function
