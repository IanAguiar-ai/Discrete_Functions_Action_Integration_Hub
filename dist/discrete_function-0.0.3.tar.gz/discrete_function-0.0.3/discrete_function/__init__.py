from .discrete_function import discrete_function
